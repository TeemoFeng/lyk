<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/5/13
 * Time: 15:13
 */

namespace app\wycadmin\model;


use app\common\model\PublicModel;

class Vehicle extends PublicModel
{
    public $modelName= '交通工具';
}